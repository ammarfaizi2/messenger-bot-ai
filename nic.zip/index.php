<?php
/**
 *
 *	Silence is golden
 *
 */
