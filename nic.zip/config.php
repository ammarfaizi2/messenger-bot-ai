<?php
define("VALIDATION_TOKEN", "858869123");

/**
 *
 *	Es Teh
 */
$config['926837650793495'] = array(
        'token'=>'EAAPFA1dRfC4BAHdGlgTwGUKdjLw6FVVkQZCbw1viZBYZBxHJF4OCO7pLGnJx1s82fFO7wbCiQOnczkjqeZCZBYAUNz0udtDL5kgJV3p80ZBpt7UevQGzPT2u5whug0O15bZCDnPYme9e1Vj9KMnXupTBIrQ35Ai3OwPmtLSqnsUWQZDZD',
        'welcome_msg'=>"Selamat datang di Bot Es Teh, bot yang dapat membantu aktivitas harian serta chatting ketika kesepian."
    );


/**
 *
 *	Anime Nocturnal
 */
$config['800281320073271'] = array(
        'token'=>'EAAPFA1dRfC4BANCpZADlenPQSSsQUscG1e8ahraWR8RYZAzMByZAqExNFqknhvjP8olOJG3lBkvaNwFxQgrTQYztSpFCHNhOeewfhSolvf6CfwqivVAPYFHnZBkdGArgZCj0heDokMyETrzQk01IZBfPNQzZA5zY4Kk9EZAQsK1PJgZDZD',
        'welcome_msg'=>'Selamat datang di Anime Nocturnal.'
    );
